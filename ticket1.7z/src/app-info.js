const appInfo = {
    title: 'App Name'
};
export default appInfo;

